<template>
   <div>
      <h3>test02.vue</h3>
   </div>  
</template>
<script>
  export default {
    created() {
   //console.log(this.$route.query.id);
   //test01 this.$router.push("/test02/19")
   //router.js {path:"/test02/:age"}
   //test02 console.log(this.$route.params.age);
    },
    data(){
     return {}
    }
  }
</script>
<style>
</style>